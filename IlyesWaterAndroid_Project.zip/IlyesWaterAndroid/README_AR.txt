Ilyes Water - مشروع Android Studio

مهم: هذا مشروع مصدر Android وليس ملف APK جاهزاً.
لبناء APK:
1) افتح Android Studio على حاسوب.
2) اختر Open وافتح مجلد IlyesWaterAndroid.
3) انتظر مزامنة Gradle وتثبيت Android SDK إذا طُلب ذلك.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد APK داخل app/build/outputs/apk/debug/.

التطبيق يحفظ البيانات محلياً على الجهاز باستخدام localStorage، ولا يحتاج إلى إنترنت أثناء الاستخدام.
احتفظ بنسخة احتياطية من بيانات الهاتف؛ حذف بيانات التطبيق قد يحذف المخزون وسجل المبيعات.
